import hashlib #Help to find checksum
import os
def CalculateCheckSum(FileName):
    fobj=open(FileName,'rb')

    hobj=hashlib.md5()

    Buffer=fobj.read(1000)

    while((len(Buffer)>0)):#Badli tn pani baher
        hobj.update(Buffer)
        Buffer=fobj.read(1024)
    
    fobj.close()
    return hobj.hexdigest() #return Calulate CheckSum

def DirectoryWatcher(DirectoryName="Marvellous"):
    Ret=False
    Ret=os.path.dirname(DirectoryName)
    if(Ret==False):
        print("There is no Such Directory")
        return
    
    Ret=os.path.isdir(DirectoryName)
    if(Ret==False):
        print("There is not a Directory")
        return
    
    for FolderName,SubFolderName,FileName in os.walk(DirectoryName):
        for fname in FileName:
         fname=os.path.join(FolderName,fname)
         CheckSum=CalculateCheckSum(fname)
         print(f"File Name : {fname} CheckSum: {CheckSum}") #f:Formatti

def main():
    DirectoryWatcher()


if __name__=="__main__":
    main()