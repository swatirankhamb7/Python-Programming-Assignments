
def main():
    try:
       fobj=open("Hello.txt","w")  #Handle :fobj
       print("File Gets Sucessfully open")

       fobj.write("Jay Ganesh Marvellous.......!")
       fobj.close()

    except FileNotFoundError:
        print("Unbale to open file as there is no such file")

    finally:
        print("End of Application")
    
if __name__=="__main__":
    main()
