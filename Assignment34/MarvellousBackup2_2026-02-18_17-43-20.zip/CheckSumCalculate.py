import hashlib #Help to find checksum
def CalculateCheckSum(FileName):
    fobj=open(FileName,'rb')

    hobj=hashlib.md5()

    Buffer=fobj.read(1000)

    while((len(Buffer)>0)):#Badli tn pani baher
        hobj.update(Buffer)
        Buffer=fobj.read(1024)
    
    fobj.close()
    return hobj.hexdigest() #return Calulate CheckSum



def main():
    Ret=CalculateCheckSum("Demo.txt")
    print("CheckSum is : ",Ret)


if __name__=="__main__":
    main()