import os
def DirectoryScanner(DirectoryName="Marvellous"):
    Ret=os.path.exists(DirectoryName)

    if(Ret==False):
        print("There is no such dorectory")
        return
    
    print("Contents of Directory are : ")
    for Foldername,SubFolderName,FileName in os.walk(DirectoryName):#return 3 parametres
        print("Folder name : ",Foldername)

        for subf in SubFolderName:
            print("SubFolder name : ",subf)
        
        for fname in FileName:
            print("File name : ",fname)

def main():
    DirectoryName=input("Enter the name of Directory : ")
    DirectoryScanner(DirectoryName)

if __name__=="__main__":
    main()