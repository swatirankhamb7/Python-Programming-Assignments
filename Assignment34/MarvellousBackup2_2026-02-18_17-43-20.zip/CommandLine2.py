import sys
def main():

    print(sys.argv[0])  #CommandLine2.py
    print(len(sys.argv)) 

if __name__=="__main__":
    main()

