import os
def main():
    DirectoryName=input("Enter the name of Directory : ")

    print("Contents of Directory are : ")

    for Foldername,SubFolderName,FileName in os.walk(DirectoryName):#return 3 parametres
        print("Folder name : ",Foldername)

        for subf in SubFolderName:
            print("SubFolder name : ",subf)
        
        for fname in FileName:
            print("File name : ",fname)


if __name__=="__main__":
    main()