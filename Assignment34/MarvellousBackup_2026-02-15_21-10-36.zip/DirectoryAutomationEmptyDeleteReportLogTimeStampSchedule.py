import os
import sys
import time
import schedule

def DirectoryScanner(DirName="Marvellous"):
    
    Boarder="-"*80
    timestamp=time.ctime()
    
    LogFileName="Marvellous%s.log" %(timestamp)
    LogFileName=LogFileName.replace(" ","_")
    LogFileName=LogFileName.replace(":","_")

    fobj=open(LogFileName,"w")
    fobj.write(Boarder+"\n")
    fobj.write("This is log file created by Marvellous Automation"+"\n")
    fobj.write("This is File Cleaner Script"+"\n")
    fobj.write(Boarder+"\n")
    
    Ret=False
    Ret=os.path.exists(DirName)
    if(Ret==False):
        print("There is no such Directory...!")

    Ret=os.path.isdir(DirName)

    if(Ret==False):
        print("It is not a directory")
        return

    FileCount=0
    EmptyFileCount=0
    for FolderName,SubFolderName,FileName in os.walk(DirName):
        for fname in FileName:
            FileCount+=1
            fname=os.path.join(FolderName,fname)

            if(os.path.getsize(fname)==0): #Empty File
                EmptyFileCount+=1
                os.remove(fname)
    
    
    fobj.write(Boarder+"\n")
    fobj.write("-----------------------Automation Report----------------------------------------"+"\n")
    fobj.write("Total files Scanned : "+str(FileCount)+"\n")
    fobj.write("Total empty file found : "+str(EmptyFileCount)+"\n")
    fobj.write("This log file is created at "+timestamp+"\n")
    fobj.write(Boarder+"\n")
   


def main():
    Boarder="-"*80
    print(Boarder)
    print("------------------------MARVELLOUS DIRECTORY AUTOMATION-------------------------")
    print(Boarder)

    if(len(sys.argv)!=2):
        print("Invalid no of Arguments")
        print("Please Specify Name of the directory")
        return
    
    #DirectoryScanner(sys.argv[1])
    schedule.every(1).minute.do(DirectoryScanner)

    while True:
        schedule.run_pending()
        time.sleep(1)

    print(Boarder)
    print("------------------------Thank you for Using Application-------------------------")
    print(Boarder)


if __name__=="__main__":
    main()