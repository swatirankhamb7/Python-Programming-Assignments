import sys

print("Number of Command Line arguments are : ",len(sys.argv)) #argv:List