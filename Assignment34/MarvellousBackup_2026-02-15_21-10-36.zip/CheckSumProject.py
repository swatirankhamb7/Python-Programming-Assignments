import hashlib #Help to find checksum
import os
import schedular

def CalculateCheckSum(FileName):
    fobj=open(FileName,'rb')

    hobj=hashlib.md5()

    Buffer=fobj.read(1000)

    while((len(Buffer)>0)):#Badli tn pani baher
        hobj.update(Buffer)
        Buffer=fobj.read(1024)
    
    fobj.close()
    return hobj.hexdigest() #return Calulate CheckSum

def FindDuplicate(DirectoryName="Marvellous"):
    Ret=False
    Ret=os.path.dirname(DirectoryName)
    if(Ret==False):
        print("There is no Such Directory")
        return
    
    Ret=os.path.isdir(DirectoryName)
    if(Ret==False):
        print("There is not a Directory")
        return
    
    Duplicate={}
    
    for FolderName,SubFolderName,FileName in os.walk(DirectoryName):
        for fname in FileName:
            fname=os.path.join(FolderName,fname)
            CheckSum=CalculateCheckSum(fname)

            if CheckSum in Duplicate:
                Duplicate[CheckSum].append(fname)
            else:
                Duplicate[CheckSum]=[fname] #print(f"File Name : {fname} CheckSum: {CheckSum}") #f:Formatting
    
    return Duplicate
             


def DisplayResult(MyDict):
    Result=list(filter(lambda x:len(x)>1,MyDict.values()))
    Count=0
    for Value in Result:
        for subvalue in Value:
            Count+=1
            print(subvalue)
    
        print("Value of Count is : ",Count)
        Count=0   

def DeleteDuplicate(path="Marvellous"):
    MyDict=FindDuplicate(path)
    Result=list(filter(lambda x:len(x)>1,MyDict.values()))
    Count=0
    Cnt=0
    for Value in Result:
        for subvalue in Value:
            Count+=1
            if(Count>1):
                print("Delete file : ",subvalue)
                os.remove(subvalue)
                Cnt=Cnt+1
        Count=0
        print("Value of Count is : ",Cnt)
 


def main():
    # Ret=FindDuplicate()
    # DisplayResult(Ret)
    DeleteDuplicate()



if __name__=="__main__":
    main()