            
def main():
    No1=int(input()) #At the time of Execution
    No2=int(input())

    print(No1+No2)

if __name__=="__main__":
    main()

