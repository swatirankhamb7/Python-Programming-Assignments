import os
import sys

def DirectoryScanner(DirName="Marvellous"):
    Ret=False
    Ret=os.path.exists(DirName)
    if(Ret==False):
        print("There is no such Directory...!")

    Ret=os.path.isdir(DirName)

    if(Ret==False):
        print("It is not a directory")
        return

    for FolderName,SubFolderName,FileName in os.walk(DirName):

        for fname in FileName:
            print("File Name : ",fname)
            print("File size : ",os.path.getsize(fname)) #Path issue
            print()


def main():
    Boarder="_"*80
    print(Boarder)
    print("------------------------MARVELLOUS DIRECTORY AUTOMATION---------------------------")
    print(Boarder)

    if(len(sys.argv)!=2):
        print("Invalid no of Arguments")
        print("Please Specify Name of the directory")
        return
    
    DirectoryScanner(sys.argv[1])

if __name__=="__main__":
    main()