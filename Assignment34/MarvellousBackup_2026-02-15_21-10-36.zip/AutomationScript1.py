import sys
def main():
    Border="-"*80
    print(Border)
    print("-"*30,"Marvellous Automation_________","-"*30)
    print(Border)

    if(len(sys.argv)==2):
        if((sys.argv[1]=="--h") or (sys.argv[1]=="--H")):
            print("This Application is used to perform ___")
            print("This is a Automation Script")

        elif((sys.argv[1]=="--u") or (sys.argv[1]=="--U")):
            print("Use the given script as")
            print("Scriptname.py Argument1 Argumen2")
            print("Argument1:---------------------")
            print("Argument2:----------------------")
        
        else:
            print("Use the Given Flags as : ")
            print("--u : Used to display the usage")
            print("--h: Used to display the help")
   
    else:
        print("Invalid No of CommandLine Arguments")
        print("Use the Given Flags as : ")
        print("--u : Used to display the usage")
        print("--h: Used to display the help")
    
    print(Border)
    print("-"*30,"Thank you for Using Script","-"*30)
    print("-"*30,"Marvellous Infosystems","-"*30)
    print(Border)


if __name__=="__main__":
    main()