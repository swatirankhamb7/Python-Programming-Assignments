import time
import datetime

def main():
    print(time.time())  #Time till today from 1 jan 1970(Linux Epoc Date)
    print(time.ctime()) #Current time
    print(datetime.datetime.now())


if __name__=="__main__":
    main()