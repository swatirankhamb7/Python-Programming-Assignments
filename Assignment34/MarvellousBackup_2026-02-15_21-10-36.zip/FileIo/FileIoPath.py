import os
#isabs():To check Absolue path

def main():
   FileName=input("Enter the name of File : ")

   Ret=os.path.isabs(FileName)

   if(Ret==True):
       print("It is Absolute Path.")
   else:
       print("It is Relative Path")
    
if __name__=="__main__":
    main()
