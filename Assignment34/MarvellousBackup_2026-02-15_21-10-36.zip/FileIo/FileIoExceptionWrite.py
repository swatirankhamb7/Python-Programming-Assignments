
def main():
    try:
       open("Hello.txt","w")
       print("File Gets Sucessfully open")

    except FileNotFoundError:
        print("Unbale to open file as there is no such file")

    finally:
        print("End of Application")
    
if __name__=="__main__":#Dunder Keyword
    main()
