#Tell- It will tell where is  file it is
def main():
    try:
       fobj=open("Hello.txt","r")  
       print("File Gets Sucessfully open") 

       print("Current offset is : ",fobj.tell())
       Data=fobj.read(6) 
       print("Current offset is : ",fobj.tell())
       
       print("Data from file is : ",Data)
       fobj.close()

    except FileNotFoundError:
        print("Unbale to open file as there is no such file")

    finally:
        print("End of Application")
    
if __name__=="__main__":
    main()
