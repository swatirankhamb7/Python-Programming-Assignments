
def main():
    try:
       fobj=open("Hello.txt","a")  #Handle :fobj
       print("File Gets Sucessfully open")

       fobj.write("Python Automation") # it will also create new File
       fobj.close()

    except FileNotFoundError:
        print("Unbale to open file as there is no such file")

    finally:
        print("End of Application")
    
if __name__=="__main__":
    main()
