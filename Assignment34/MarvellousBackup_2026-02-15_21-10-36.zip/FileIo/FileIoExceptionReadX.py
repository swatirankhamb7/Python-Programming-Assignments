
def main():
    try:
       fobj=open("Hello.txt","r")  
       print("File Gets Sucessfully open") 
       Data=fobj.read(6) #parameter to read no of bytes
       print("Data from file is : ",Data)
       fobj.close()

    except FileNotFoundError:
        print("Unbale to open file as there is no such file")

    finally:
        print("End of Application")
    
if __name__=="__main__":
    main()
