
def main():
    try:
       open("Demo.txt")
       print("File Gets Sucessfully open")
    except FileNotFoundError:
        print("Unbale to open file as there is no such file")
    finally:
        print("Inside finally")
    
if __name__=="__main__":#Dunder Keyword
    main()
