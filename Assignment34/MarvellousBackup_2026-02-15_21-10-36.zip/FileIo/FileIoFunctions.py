import os
#isabs():To check Absolue path

def main():
   FileName=input("Enter the name of File : ")

   if(os.path.exists(FileName)):
        fobj=open(FileName,"r")

        print(fobj.name)#Get the file name(Demo.txt)
        print(fobj.mode)#To check the mode of the file(R)
        print(fobj.closed)#To check file closed(False)

        fobj.close()
        print(fobj.closed)#True

   else:
       print("There is no such a File.")
        
if __name__=="__main__":
    main()
