import os
#isabs():To check Absolue path

def main():
   FileName=input("Enter the name of File : ")

   if(os.path.exists(FileName)):
        os.remove(FileName)
        print("File Gets Deleted.....")
   else:
       print("There is no such a File.")
        
if __name__=="__main__":
    main()
