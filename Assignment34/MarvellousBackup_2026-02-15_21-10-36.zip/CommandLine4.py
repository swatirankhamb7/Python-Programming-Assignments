#python CommandLine4.py 11 10
import sys

def main():
    print("Command Line Arguments are : ")
    No1=int(sys.argv[1])
    No2=int(sys.argv[2])
    Ans=No1+No2
    print("Addition is : ",Ans)
   

if __name__=="__main__":
    main()

